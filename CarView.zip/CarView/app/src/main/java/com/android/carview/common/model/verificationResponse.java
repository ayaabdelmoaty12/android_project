package com.android.carview.common.model;

import com.google.gson.annotations.SerializedName;

public class verificationResponse
{
    @SerializedName("error")
    public String error;
}
